import React, {Component} from 'react';
import axios from 'axios';
import Student from './Student';
import App from './../App.css';

export class About extends Component {
  constructor (props) {
    super (props);

    this.state = {
      contacts: [],
      per: 2,
      page: 1,
      totalPages: null,
      isLoading: true,
    };
  }
  componentWillMount () {
    console.log (this.state);
    this.loadContacts ();
  }
  loadContacts () {
    const {per, page, contacts} = this.state;
    const url = `https://student-example-api.herokuapp.com/v1/contacts.json?per=${per}&page=${page}`;
    axios
      .get (url)
      .then (json => {
        this.setState ({
          //  contacts: resp['data']['contacts'],
          contacts: [...contacts, ...json.data.contacts],
          isLoading: false,
        });
      })
      .catch (err => console.log (err));
  }
  loadMore = () => {
    this.setState (
      prevState => ({
        page: prevState.page + 1,
      }),
      this.loadContacts
    );
  };
  render () {
    return (
      <div className="container">

        <ul className="contact">
          {this.state.contacts.map (contact => (
            <li key={contact.id}>
              <Student {...contact} />
            </li>
          ))}

        </ul>

        <a onClick={this.loadMore}>Load More</a>
      </div>
    );
  }
}

export default About;
