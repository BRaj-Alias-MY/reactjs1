import React from 'react';

function Contact () {
  return (
    <div className="container">
      <h1>Contact Page</h1>
      <div>Contact page content here</div>
    </div>
  );
}

export default Contact;
